package com.eatza.order;

import static org.junit.Assert.*;

import org.junit.Test;

public class OrderingserviceApplicationTest {

	@Test
	public void testMain() {
	
	}

	@Test
	public void testJwtFilterBean() {
	
	}

}
