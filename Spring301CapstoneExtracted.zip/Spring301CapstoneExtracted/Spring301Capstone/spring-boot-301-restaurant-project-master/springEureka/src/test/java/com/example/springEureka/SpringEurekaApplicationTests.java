package com.example.springEureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
