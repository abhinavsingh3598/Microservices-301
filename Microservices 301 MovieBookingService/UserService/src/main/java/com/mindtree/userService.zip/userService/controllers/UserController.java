package com.mindtree.userService.controllers;

public class UserController {

}
